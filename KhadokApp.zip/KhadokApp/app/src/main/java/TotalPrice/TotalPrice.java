package TotalPrice;

public class TotalPrice {

    public static int totalPrice = 0;

}
